/*
// To load this framework, add the following code in your manifest.json

"commands": [
:
:
{
    "script" : "SupernovaUI.framework/SupernovaUI.js",
    "handlers" : {
        "actions" : {
            "Startup" : "onStartup",
            "OpenDocument":"onOpenDocument",
            "SelectionChanged.finish" : "onSelectionChanged"
        }
    }
}
]
*/

var onStartup = function(context) {
  var SupernovaUI_FrameworkPath = SupernovaUI_FrameworkPath || COScript.currentCOScript().env().scriptURL.path().stringByDeletingLastPathComponent().stringByDeletingLastPathComponent();
  var SupernovaUI_Log = SupernovaUI_Log || log;
  (function() {
    var mocha = Mocha.sharedRuntime();
    var frameworkName = "SupernovaUI";
    var directory = SupernovaUI_FrameworkPath;
    if (mocha.valueForKey(frameworkName)) {
      SupernovaUI_Log("😎 loadFramework: `" + frameworkName + "` already loaded.");
      return true;
    } else if ([mocha loadFrameworkWithName:frameworkName inDirectory:directory]) {
      SupernovaUI_Log("✅ loadFramework: `" + frameworkName + "` success!");
      mocha.setValue_forKey_(true, frameworkName);
      return true;
    } else {
      SupernovaUI_Log("❌ loadFramework: `" + frameworkName + "` failed!: " + directory + ". Please define SupernovaUI_FrameworkPath if you're trying to @import in a custom plugin");
      return false;
    }
  })();
};

var onSelectionChanged = function(context) {
  SupernovaUI.onSelectionChanged(context);
};


var onAllMethods = function(content) {
    SupernovaUI.onAllMethods(context);
};
